﻿public class Musician
{
    public string Name;
    public string Insturment;
}
